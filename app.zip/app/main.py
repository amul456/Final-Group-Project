from flask import Flask
import pymongo
from pymongo import MongoClient
import json
from bson import json_util

client = MongoClient("mongodb+srv://amul:amul456@cluster0.zpxfx.mongodb.net/crypto_db?retryWrites=true&w=majority")
db = client.get_database('crypto_db')
collection = db ["seeds"]

app = Flask(__name__)

@app.route("/seeds", methods=["GET"])
def get_seeds():
    all_seeds = list(collection.find(())) 
    return json.dumps(all_seeds, default=json_util.default)

