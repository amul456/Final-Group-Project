from flask import Flask, jsonify, request, render_template
import os

app = Flask(__name__)

PicFolder = os.path.join('static')
app.config['upload_folder'] = PicFolder

@app.route('/')
def index():
    pic1 = os.path.join(app.config['upload_folder'],'pic1.jpg')
    return render_template ("index.html", user_image = pic1)

@app.route('/google-charts/pie-chart')
def google_pie_chart():
    data = {'Task' : 'Hours per Day', 'Data programing': 11, 'Math': 2, 'Data Manipulation': 2, 'Data System': 2, 'Encoding': 7}
    return render_template("pie-chart.html", data=data)

@app.route('/about')
def about():
    return render_template("about.html")

@app.route('/crypto')
def crypto():
    return render_template("crypto.html")


if __name__ == "__main__":
    app.run()  